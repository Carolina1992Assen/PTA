

import nltk
import random
from collections import Counter
from nltk.corpus import wordnet
from nltk.stem.wordnet import WordNetLemmatizer

print("Exercise 1")
print("1a")

noun_lemmas = []

text = open('ada_lovelace.txt').read()
tokens = nltk.wordpunct_tokenize(text)
pos_tags = nltk.pos_tag(tokens)

"""Check if a word is a noun"""
def is_noun(tag):
    return tag in ['NN', 'NNS', 'NNP', 'NNPS']


def hypernymOf(synset1, synset2):
    if synset1 == synset2:
        return True
    for hypernym in synset1.hypernyms():
        if synset2 == hypernym:
            return True
        if hypernymOf(hypernym, synset2):
            return True
    return False

lemmatizer = WordNetLemmatizer()

noun_list = [word for word, pos in pos_tags if is_noun(pos)]
noun_lemmas = []
synset_list = []

for noun in noun_list:
    noun = lemmatizer.lemmatize(noun, wordnet.NOUN)
    noun_lemmas.append(noun)


for lemma in noun_lemmas:
    synset = wordnet.synsets(lemma, pos='n')
    synset_list.append(synset)

# Get the right synset of relative
relative = wordnet.synsets("relative", pos='n')[0]
relative_list = []

# Find hyponyms in text
for synset in synset_list:
    if len(synset) > 0:
        for i in range(len(synset)):
            if hypernymOf(synset[i], relative):
                relative_list.append(synset[i])

print("How many nouns refer to a relative?:", len(relative_list))
print(relative_list)

print("\n1b")
# Get the right synset of illness
illness = wordnet.synsets("illness", pos='n')[0]
illness_list = []

# Find hyponyms in text
for synset in synset_list:
    if len(synset) > 0:
        for i in range(len(synset)):
            if hypernymOf(synset[i], illness):
                illness_list.append(synset[i])

print("How many nouns refer to an illness?:", len(illness_list))
print(illness_list)

print("\n1c")
# Get the right synset of illness
science = wordnet.synsets("science", pos='n')[0]
science_list = []

# Find hyponyms in text
for synset in synset_list:
    if len(synset) > 0:
        for i in range(len(synset)):
            if hypernymOf(synset[i], science):
                science_list.append(synset[i])

print("How many nouns refer to a science?:", len(science_list))
print(science_list)

print("\n2 - Multiple classes")

nouns_list = []
hypernyms_list = []

# Make lists of nouns and corresponding synsets
for noun in noun_lemmas:
    nouns_list.append((noun, wordnet.synsets(noun, pos='n')))
for nouns, synsets in nouns_list:
    if len(synsets) > 0:
        for synset in synsets:
            hypernyms_list.append((nouns, synset.lexname()))

count_one_hypernym = 0
count_multiple_hypernyms = 0

one_hypernym_list = []
multiple_hypernyms_list = []

hypernyms_countlist = Counter(hypernyms_list)

# Check if words have more than one hypernym or only 1
for k, v in hypernyms_countlist.items():
    if v == 1:
        count_one_hypernym += 1
        one_hypernym_list.append(k)
    elif v > 1:
        count_multiple_hypernyms += 1
        multiple_hypernyms_list.append(k)

print("\nIn", count_one_hypernym, "cases there was only one hypernym per noun. Examples:")
print(random.choice(one_hypernym_list))
print(random.choice(one_hypernym_list))
print(random.choice(one_hypernym_list))

print("\nIn", count_multiple_hypernyms, "cases there was only one hypernym per noun. Examples:")
print(random.choice(multiple_hypernyms_list))
print(random.choice(multiple_hypernyms_list))
print(random.choice(multiple_hypernyms_list))

count_nouns = 0
count_hypernyms = 0

number_of_nouns = len(noun_lemmas)
number_of_hypernyms = len(hypernyms_list)
# Calculate average
print("\nAverage hypernym per noun:", number_of_hypernyms/number_of_nouns)


#1.3
def getMaxSim(synsets1, synsets2):
    maxSim = None
    for s1 in synsets1:
        for s2 in synsets2:
            sim = s1.lch_similarity(s2)
            if maxSim == None or maxSim < sim:
                maxSim = sim
    return maxSim

carSynsets = wordnet.synsets("car", pos="n")
automobileSynsets = wordnet.synsets("automobile", pos="n")
coastSynsets = wordnet.synsets("coast", pos="n")
shoreSynsets = wordnet.synsets("shore", pos="n")
foodSynsets = wordnet.synsets("food", pos="n")
fruitSynsets = wordnet.synsets("fruit", pos="n")
journeySynsets = wordnet.synsets("journey", pos="n")
monkSynsets = wordnet.synsets("monk", pos="n")
slaveSynsets = wordnet.synsets("slave", pos="n")
moonSynsets = wordnet.synsets("slave", pos="n")
stringSynsets = wordnet.synsets("string", pos="n")

print("\n1.3")
print("rank 1: car<>automobile:", getMaxSim(carSynsets, automobileSynsets))
print("rank 2: coast<>shore:", getMaxSim(coastSynsets, shoreSynsets))
print("rank 3: monk<>slave:", getMaxSim(monkSynsets, slaveSynsets))
print("rank 4: moon<>string:", getMaxSim(moonSynsets, stringSynsets))
print("rank 5: food<>fruit:", getMaxSim(foodSynsets, fruitSynsets))
print("rank 6: journey<>car:", getMaxSim(journeySynsets, carSynsets))
print("The first two ranks in my ranking are the same as in the experiment, \
rank 3 and 4 in my ranking are on rank 5 and 6 in the experiment, \
and rank 5 and 6 in my ranking are on rank 3 and 4 in the experiment. \
Thus, when looking at the rankings, mine and the experiment rankings \
are not close.")
