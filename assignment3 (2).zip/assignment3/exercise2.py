from nltk.tag import StanfordNERTagger
from collections import Counter

#2.1
print("2.1")
path_model = '/Downloads/stanford-ner/classifiers/english.all.3class.distsim.crf.ser.gz' #here path to model file
path_jar = '/Downloads/stanford-ner/stanford-ner.jar' #here path to stanford-ner.jar file
st = StanfordNERTagger(path_model, path_jar)

with open('ada_lovelace.txt') as f:
    tagged_tokens = st.tag(f.read().split())
    print(tagged_tokens)
    counts = Counter(item[1] for item in tagged_tokens)
    print("\nThere are {0} Persons in the text".format(counts['PERSON']))
    print("There are {0} Organizations in the text".format(counts['ORGANIZATION']))
    print("There are {0} Locations in the text".format(counts['LOCATION']))
    print("Not all words are classified in the correct named entity classification "\
          "for example Augusta and Ada are tagged as Organization and as Person.")
